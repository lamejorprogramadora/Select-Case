﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim a As Integer
        Dim b As String
        a = TextBox1.Text
        Select Case (a)
            Case 1
                b = "Enero"
            Case 2
                b = "Febrero"
            Case 3
                b = "Marzo"
            Case 4
                b = "Abril"
            Case 5
                b = "Mayo"
            Case 6
                b = "Junio"
            Case 7
                b = "Julio"
            Case 8
                b = "Agosto"
            Case 9
                b = "Septiembre"
            Case 10
                b = "Octubre"
            Case 11
                b = "Noviembre"
            Case 12
                b = "Diciembre"
            Case Else
                b = "Error"

        End Select
        TextBox2.Text = b

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
